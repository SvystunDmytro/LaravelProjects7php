<?php $__env->startSection('baner'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="main-content-inner content-width">


            <!-- Main Column / Sidebar -->

            <div class="column-container">


                <!-- Main Column -->

                <div class="column-three-qtr">


                    <!-- Blog Post -->
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog-post">
                            <!-- Title -->
                            <h1><a href="news/<?php echo e($new->id); ?>"><?php echo e($new->title); ?></a></h1>
                            <!-- Meta -->
                            <div class="blog-meta">
                                <div class="meta-item">
                                    <div class="meta-title published">Дата:</div>
                                    <a href="#"><?php echo e($new->created_at); ?></a></div>
                                <div class="meta-item">
                                    <div class="meta-title views">Просмотры:</div>
                                    <a href="#">9</a></div>
                                <div class="meta-item">
                                    <div class="meta-title comments">Комментарии:</div>
                                    <a href="#">2</a></div>
                                <div class="meta-item">
                                    <div class="meta-title tags">Теги</div>
                                    <a href="#">новости</a>, <a href="#">шаблоны</a></div>
                            </div>
                            <!-- Image -->
                            <a href="news/<?php echo e($new->id); ?>" class="media image-link"><img alt="" src="<?php echo e($new->img_path); ?>"
                                                                                      class="fullwidth"></a>
                            <!-- Excerpt -->
                            <div class="blog-content">
                                <p><?php echo e($new->short_discription); ?> ...</p>
                                <!-- Read More Button -->
                                <a href="news/<?php echo e($new->id); ?>" class="button accent">Читать далее</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- END Blog Post -->

                        <!-- Navigation -->


                        <div class="blog-nav">
                            <a href="#" class="back">Назад</a>
                            <a href="#" class="next">Вперед</a>
                        </div>


                        <!-- END Navigation -->


                </div>

                <!-- END Main Column -->

                <?php echo $__env->make('news.sidebarNews', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <!-- Sidebar -->


                <!-- END Sidebar -->


            </div>

            <!-- END Main Column / Sidebar -->


        </div>
    </div>
    
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-width'); ?> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>