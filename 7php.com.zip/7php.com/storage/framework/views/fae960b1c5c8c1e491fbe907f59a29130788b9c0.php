<?php $__env->startSection('head'); ?>
    ##parent-placeholder-1a954628a960aaef81d7b2d4521929579f3541e6##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('topbar-menu'); ?>
    ##parent-placeholder-aa9626af9f01ab09359b6bb0369b7817d1e755a6##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

    <div class="main-content">
        <div class="main-content-inner content-width">

            <div class="column-container">

                <div class="column-one-third">
                    <div class="icons-column">
                        <!-- Icon Backing -->
                        <div class="icon-backing" style="background-color: #916C6C;">
                            <!-- Icon -->
                            <i class="fa fa-heart"></i>
                        </div>
                    </div>
                    <div class="content-column">
                        <!-- Title -->
                        <h3>Дизайн</h3>
                        <!-- Text -->
                        <p>Интересно отметить, что каждая сфера рынка притягивает план размещения. </p>
                    </div>
                </div>

                <div class="column-one-third">
                    <div class="icons-column">
                        <!-- Icon Backing -->
                        <div class="icon-backing" style="background-color: #7089AD;">
                            <!-- Icon -->
                            <i class="fa fa-font"></i>
                        </div>
                    </div>
                    <div class="content-column">
                        <!-- Title -->
                        <h3>Верстка</h3>
                        <!-- Text -->
                        <p>Интересно отметить, что каждая сфера рынка притягивает план размещения. </p>
                    </div>
                </div>

                <div class="column-one-third">
                    <div class="icons-column">
                        <!-- Icon Backing -->
                        <div class="icon-backing" style="background-color: #63885F;">
                            <!-- Icon -->
                            <i class="fa fa-fullscreen"></i>
                        </div>
                    </div>
                    <div class="content-column">
                        <!-- Title -->
                        <h3>Разработка</h3>
                        <!-- Text -->
                        <p>Интересно отметить, что каждая сфера рынка притягивает план размещения. </p>
                    </div>
                </div>

            </div>

            <div class="divider"></div>

            <h3 class="section-title">Последние события</h3>

            <div id="portfolio-nav" class="carousel-nav">
                <div class="back"></div>
                <div class="next"></div>
            </div>

            <div class="carousel">
                <ul id="portfolio-carousel" class="slider-container">

                    <!-- One Fourth -->

                    <li class="column-one-fourth portfolio-item branding">
                        <!-- Image -->
                        <a href="#" class="image-link"><img alt="" src="\public\images\placeholders\preview6.jpg" class="fullwidth">
                        </a>
                        <!-- Title -->
                        <h3><a href="#">Название события</a></h3>
                        <!-- Tags -->
                        <div class="tags">Категория</div>
                    </li>

                    <!-- END One Fourth -->


                </ul>
            </div>

            <div class="column-container">
                <div class="column-three-qtr">
                    <div class="divider"></div>
                    <h3 class="section-title">Последние новости</h3>
                    <div id="blog-nav" class="carousel-nav">
                        <div class="back"></div>
                        <div class="next"></div>
                    </div>
                    <div class="carousel">
                        <ul id="blog-carousel" class="slider-container">


                            <!-- One Fourth -->
                            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="column-one-fourth">
                                    <!-- Image -->
                                    <a href="news/<?php echo e($new->id); ?>}" class="image-link"><img alt="" src="\public\images\placeholders\preview8.jpg" class="fullwidth">
                                    </a>
                                    <!-- Title -->
                                    <h3><a href="news/<?php echo e($new->id); ?>}"> <?php echo e($new->title); ?> </a></h3>
                                    <!-- Date -->
                                    <div class="date"><?php echo e($new->created_at); ?></div>
                                    <!-- Excerpt -->
                                    <p><?php echo e($new->short_discription); ?> </p>
                                    <!-- Read More Link -->
                                    <a href="news/<?php echo e($new->id); ?>}">Подробнее</a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <!-- END One Fourth -->
                        </ul>
                    </div>

                </div>

            </div>

        </div>
    </div>


    <?php echo $__env->yieldSection(); ?>
    




    
        
            
            
            
        
    

<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>