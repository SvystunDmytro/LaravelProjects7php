<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div>
                        <h2>News =>  <b>Просмотр всех новостей на сайте</b></h2>

                    </div>

                    

                </div>
            </div>
            <table class="table table-striped table-hover">
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Название</th>
                    
                    <th>Текст новости</th>
                    <th>Краткое описание</th>
                    
                    <th>Категория</th>
                    
                    <th>Action</th>
                </tr>
                </thead>

                <tbody>
                <?php if(\Session::has('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e(\Session::get('success')); ?></p>
                    </div><br />
                <?php endif; ?>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e($item->content); ?></td>
                        <td><?php echo e($item->short_discription); ?></td>
                        <td><?php echo e($item->category_id); ?></td>
                        <td><?php echo e($item->img_path); ?></td>
                        <td>
                            <a href="<?php echo e(url("admin/news/{$item->id}/edit")); ?>" class="settings" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE8B8;</i></a>
                            <a href="" class="comment" title="comment" data-toggle="tooltip"><i class="fa">&#xf086;</i></a>
                            <form  action="<?php echo e(URL('admin/'.$item->id)); ?>"  method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="delete" title="Delete" data-toggle="tooltip"><i class="material-icons">&#xE5C9;</i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
            <div class="clearfix">
                
                <ul class="pagination">
                    
                </ul>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div><br />
            <?php endif; ?>
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e(\Session::get('success')); ?></p>
                </div><br />
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>