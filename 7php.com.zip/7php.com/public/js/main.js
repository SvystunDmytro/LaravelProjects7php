/**
 * Created by Dmytro on 26.02.2018.
 *
 * You can find this script at Recourse\views\layouts\layout.blade.php position DOWN
 * <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 * <script type="text/javascript" src="{!! asset('js/main.js')!!}"></script>
 *
 */

$(document).ready(function () {
    //
    // $('.sidebar-widget.categories a').click( function(event) {
    //     event.preventDefault();
    //     var catId = $(this).attr('cat-id');

    //     $.ajax({
    //         url: '/news/category/' + catId,
    //         method: 'GET',
    //         success: function (response) {
    //             var $html = $(response).find('.column-three-qtr').html();
    //             $('.column-three-qtr').html($html);
    //             console.log(1212);
    //             //return view('news.news', compact('news','cat'))
    //         }
    //     });
    //
    // });
    //
    //
    // $('.deleteNews').click(function (event) {
    //     event.preventDefault();
    //     alert('Yupi Yei. Your product has been deleted')
    //
    // })



});